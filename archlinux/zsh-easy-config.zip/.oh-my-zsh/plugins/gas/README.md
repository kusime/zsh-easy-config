# Gas plugin

This plugin adds autocompletion for the [gas](http://walle.github.com/gas) command,
a utility to manage Git authors.

To use it, add `gas` to the plugins array of your zshrc file:

```zsh
plugins=(... gas)
```
